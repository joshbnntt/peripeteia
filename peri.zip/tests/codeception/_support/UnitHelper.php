<?php
namespace Codeception\Module;

// here you can define custom functions for UnitTester

class UnitHelper extends \Codeception\Module
{
}
