describe("HomeController", function() {
  beforeEach(inject(function($controller, $rootScope, _$location_, _restService_) {
    scope = $rootScope.$new();
    $location = _$location_;
    scope.userInfo

    $controller('ListLibrariesCtrl',
              {$scope: scope, $location: $location, restService: restService });

    scope.$digest();
}));

  it("should be able to display all availeable course outlines", function() {
    expect($location).toEqual('/');
    expect(scope.course_outlines).toEqual
  });

  describe("when song has been paused", function() {
    beforeEach(function() {
      player.play(song);
      player.pause();
    });

    it("should indicate that the song is currently paused", function() {
      expect(player.isPlaying).toBeFalsy();

      // demonstrates use of 'not' with a custom matcher
      expect(player).not.toBePlaying(song);
    });

    it("should be possible to resume", function() {
      player.resume();
      expect(player.isPlaying).toBeTruthy();
      expect(player.currentlyPlayingSong).toEqual(song);
    });
  });

  // demonstrates use of spies to intercept and test method calls
  it("tells the current song if the user has made it a favorite", function() {
    spyOn(song, 'persistFavoriteStatus');

    player.play(song);
    player.makeFavorite();

    expect(song.persistFavoriteStatus).toHaveBeenCalledWith(true);
  });

  //demonstrates use of expected exceptions
  describe("#resume", function() {
    it("should throw an exception if song is already playing", function() {
      player.play(song);

      expect(function() {
        player.resume();
      }).toThrowError("song is already playing");
    });
  });
});
